import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
public class DataUtil
{
    public ArrayList<String> getSubjects(){
        ArrayList<String> outputSubjects = new ArrayList<String>();
        
        try{
            decryptAllFiles();
            BufferedReader br = new BufferedReader(new FileReader("TextFiles\\TeacherRecords.txt"));
            String nextLine = br.readLine();
            HashSet<String> subjects = new HashSet<String>();
            while(nextLine != null){
                String[] lineParts = nextLine.split(",");
                subjects.add(lineParts[3]);
                nextLine = br.readLine();
            }
            br.close();
            encryptAllFiles();
            for(String subject : subjects){
                outputSubjects.add(subject);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return outputSubjects;
    }
    
    public void encryptAllFiles(){
        shiftAllFiles(10);
    }
    
    public void decryptAllFiles(){
        shiftAllFiles(-10);
    }
    
    public void shiftAllFiles(int shiftAmount){
        JOptionPane.showMessageDialog(null, "This should be a one time use and will break existing encryption","WARNING", JOptionPane.WARNING_MESSAGE);
        int result = JOptionPane.showConfirmDialog(null, "Proceed?","WARNING", JOptionPane.OK_CANCEL_OPTION);
        
        if(result == JOptionPane.OK_OPTION){
            File folder = new File("./TextFiles");
            File[] listOfTextFiles = folder.listFiles();
            ArrayList<String> filePaths = new ArrayList<String>();
            for(int i = 0; i < listOfTextFiles.length; i++){
                if(listOfTextFiles[i].isFile()){
                    if(listOfTextFiles[i].getName().split("\\.")[1].equals("txt")){
                        filePaths.add("TextFiles\\"+ listOfTextFiles[i].getName());
                    }
                }
            }
            
            for(String filepath : filePaths){
                try{
                    BufferedReader br = new BufferedReader(new FileReader(filepath));
                    String nextLine = "";
                    ArrayList<String> fileContent = new ArrayList<String>();
                    while( (nextLine = br.readLine()) != null){
                        String encryptedLine = "";
                        for(int i = 0; i < nextLine.length(); i++){
                            int encryptedNum = (int) nextLine.charAt(i) + shiftAmount;
                            encryptedLine += (char) encryptedNum;
                        }
                        fileContent.add(encryptedLine);
                    }
                    br.close();
                    
                    BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
                    for(String line : fileContent){
                        bw.write(line);
                        bw.newLine();
                    }
                    bw.close();
                    
                    
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
            
            
        }else{
            JOptionPane.showMessageDialog(null,"Cancelled");
            return;
        }
    }
    
}
